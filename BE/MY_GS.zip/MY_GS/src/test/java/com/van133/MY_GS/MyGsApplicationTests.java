package com.van133.MY_GS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyGsApplicationTests {

	@Test
	void contextLoads() {
	}

}
