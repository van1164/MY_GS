package com.van133.MY_GS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyGsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyGsApplication.class, args);
	}

}
